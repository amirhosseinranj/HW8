// Amirhossein Ranjbar   40223037
#include <stdio.h>
#include <string.h>



struct time
{
    int min;
    int sec;
};

struct runner
{
    char firstName[50];
    char lastName[50];
    int ID;
    struct time *record;
    struct time runningtime;
};
  

int main ()
{
    int num;

    printf("Enter number of participants\n");

    scanf("%d", &num);

    struct time TIME;
    struct runner array[num];
    
    struct runner temp[num];

    int records[num];
    int runningtimes[num];
    

    printf("Enter information of participants\n");

    for(int i=0;i<num;i++)
    {
        array[i].record = &TIME;

        scanf("%s %s %d", &array[i].firstName, &array[i].lastName, &array[i].ID);

        scanf("%d %d", &array[i].record->min,&array[i].record->sec );

        scanf("%d %d", &array[i].runningtime.min, &array[i].runningtime.sec);

        records[i] = (array[i].record->min)*60 + (array[i].record->sec);
       
        runningtimes[i] = (array[i].runningtime.min)*60 + (array[i].runningtime.sec);
    }   
    
        int p=0;
        int q=0;
        char winner1[50];
        char winner2[50];

        for(int k=0;k<(num);k++)
            for(int h=k;h<num;h++)
            {
           
            if (runningtimes[h]<=runningtimes[k])
            {
                 
                p = runningtimes[h];
                q = records[h];
                strcpy(winner1 , array[h].firstName);
                strcpy(winner2 , array[h].lastName);
            }
           
            }
        

        printf("the winner is %s %s\n", winner1, winner2);

        if(p<q)
            printf("he could break his record\n");
        else
            printf("he could not break his record\n");    
        

        int w=0;

        for(int l=0;l<(num);l++)
        {
            for(int z=0;z<num;z++)
            {
            if(records[z]<=records[l])
                w = records[z];
            
            }
        }

        if(p<w)
            printf("he could break the best record\n");
        else
            printf("he could not break the best record\n");

        for(int i=0;i<num;i++){
        for(int j=i;j<num;j++){
            if(runningtimes[j]>runningtimes[j+1]){
                 temp[j] = array[j];
                array[j] = array[j+1];
                array[j+1] = temp[j];
            }
        } 
    }

    printf("%-20s %-20s %-10s %-10s %-10s %-10s %-10s\n","firstName","lastName","ID","record(min)",
    "record(sec)","runningtime(min)","rinningtime(sec)");


    for(int i=0;i<num;i++){
    printf("%-20s %-20s %-10d %-15d %-15d %-15d %-15d\n",array[i].firstName,array[i].lastName,array[i].ID,array[i].record->min,
    array[i].record->sec,array[i].runningtime.min,array[i].runningtime.sec);
    }
    
    return 0;
}